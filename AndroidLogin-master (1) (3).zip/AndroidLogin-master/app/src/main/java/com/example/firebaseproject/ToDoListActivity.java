package com.example.firebaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class ToDoListActivity extends AppCompatActivity {

    private Button button;
    private ArrayList<String> items;
    private ArrayAdapter<String> itemsAdapter;
    private ListView listView;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do_list);

        listView = findViewById(R.id.listView);
        button = findViewById(R.id.buttonTodo);
        editText = findViewById(R.id.editTextToDo);

        loadItems(); // Load items from SharedPreferences

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem();
            }
        });

        setUpListViewListener();
    }

    private void addItem() {
        String itemText = editText.getText().toString();

        if (!itemText.equals("")) {
            itemsAdapter.add(itemText);
            editText.setText(""); // Clear the EditText after adding the item
            saveItems(); // Save items after adding
        } else {
            Toast.makeText(getApplicationContext(), "Please enter text...", Toast.LENGTH_LONG).show();
        }
    }

    private void setUpListViewListener() {
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Context context = getApplicationContext();
                Toast.makeText(context, "Item Removed", Toast.LENGTH_LONG).show();
                items.remove(position);
                itemsAdapter.notifyDataSetChanged();
                saveItems(); // Save items after removal
                return true;
            }
        });
    }

    private void saveItems() {
        SharedPreferences prefs = getSharedPreferences("ToDoListPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("items", TextUtils.join(",", items));
        editor.apply();
    }

    private void loadItems() {
        SharedPreferences prefs = getSharedPreferences("ToDoListPrefs", Context.MODE_PRIVATE);
        String itemsString = prefs.getString("items", "");
        if (!itemsString.equals("")) {
            String[] itemsArray = itemsString.split(",", -1);
            items = new ArrayList<>(Arrays.asList(itemsArray));
        } else {
            items = new ArrayList<>();
        }
        itemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(itemsAdapter);
    }
}
