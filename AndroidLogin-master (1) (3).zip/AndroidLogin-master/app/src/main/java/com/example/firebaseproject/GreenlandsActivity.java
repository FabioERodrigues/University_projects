package com.example.firebaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GreenlandsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_greenlands);
        Button openWebButton = findViewById(R.id.buttonforGL);

        // Set an OnClickListener for the button
        openWebButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Henley+Business+School,+Greenlands+Campus/@51.5213618,-0.8046402,11z/data=!4m21!1m11!3m10!1s0x4876906fb97a749d:0x6a4e3e2dd18e5d6c!2sHenley+Business+School,+Greenlands+Campus!5m2!4m1!1i2!8m2!3d51.5633239!4d-0.8840109!10e5!16zL20vMDgxdmtk!3m8!1s0x4876906fb97a749d:0x6a4e3e2dd18e5d6c!5m2!4m1!1i2!8m2!3d51.5633239!4d-0.8840109!16zL20vMDgxdmtk?entry=ttu"));
                startActivity(intent);

                // Start the activity with the intent if it can be handled
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
    }
}