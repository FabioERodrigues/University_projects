package com.example.firebaseproject;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class MyViewPagerAdapter  extends FragmentStateAdapter {
    public MyViewPagerAdapter(@NonNull CalendarActivity fragment) {
        super(fragment);
    }


    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new MonFrag();

            case 1:
                return new TueFrag();

            case 2:
                return new WedFrag();

            case 3:
                return new ThursFrag();

            case 4:
                return new FriFrag();

            default:
                return new MonFrag();
        }

    }

    @Override
    public int getItemCount() {
        return 5;
    }
}