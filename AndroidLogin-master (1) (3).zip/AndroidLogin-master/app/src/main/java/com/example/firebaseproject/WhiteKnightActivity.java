package com.example.firebaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.firebaseproject.R;

public class WhiteKnightActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_white_knight);
        // Find the button by its ID
        Button openWebButton = findViewById(R.id.buttonforWK);

        // Set an OnClickListener for the button
        openWebButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Whiteknights+Rd,+Reading/@51.4440708,-0.9393948,17z/data=!3m1!4b1!4m6!3m5!1s0x487684b6b7e3ed33:0xa55d09ac1294b349!8m2!3d51.4440675!4d-0.9368199!16s%2Fg%2F1tdd9blh?entry=ttu"));
                startActivity(intent);

                // Start the activity with the intent if it can be handled
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
    }
}