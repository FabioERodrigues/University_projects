package com.example.firebaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LondonCamActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_london_cam);
        Button openWebButton = findViewById(R.id.buttonforLC);

        // Set an OnClickListener for the button
        openWebButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/London+Road+Campus/@51.45024,-0.9652341,17z/data=!3m1!4b1!4m6!3m5!1s0x48769b38df957b4d:0xb09981718988f28c!8m2!3d51.4502367!4d-0.9626592!16zL20vMGYzeHR3?entry=ttu"));
                startActivity(intent);

                // Start the activity with the intent if it can be handled
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
    }
}