package com.example.firebaseproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class TR_RecylerViewAdapter extends RecyclerView.Adapter<TR_RecylerViewAdapter.MyViewHolder> {
    Context context;
    ArrayList<TimetableRow> timetableRow;

    public TR_RecylerViewAdapter(Context context,ArrayList<TimetableRow> timetableRow ){
        this.context = context;
        this.timetableRow = timetableRow;

    }
    @NonNull
    @Override
    public TR_RecylerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // This is where you inflate the layout (Giving a look to our rows)
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.timetable_row, parent,  false);
        return new TR_RecylerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TR_RecylerViewAdapter.MyViewHolder holder, int position) {
        /* assigning values to each of our rows */
        holder.tvName.setText(timetableRow.get(position).getModuleName());
        holder.tvLoc.setText(timetableRow.get(position).getModuleLocation());
        holder.tvTime.setText(timetableRow.get(position).getModuleTime());
    }

    @Override
    public int getItemCount() {
        /* total number of items in recycler view */
        return timetableRow.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tvName,tvLoc, tvTime;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.moduleName);
            tvLoc = itemView.findViewById(R.id.moduleLocation);
            tvTime = itemView.findViewById(R.id.moduleTime);
        }
    }
}
