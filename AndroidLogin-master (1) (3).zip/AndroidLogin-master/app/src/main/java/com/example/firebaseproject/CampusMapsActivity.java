package com.example.firebaseproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CampusMapsActivity extends AppCompatActivity implements View.OnClickListener {
    public CardView card1, card2, card3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campus_maps);
        card1 = (CardView) findViewById(R.id.map1);
        card2 = (CardView) findViewById(R.id.map2);
        card3 = (CardView) findViewById(R.id.map3);


        card1.setOnClickListener(this);
        card2.setOnClickListener(this);
        card3.setOnClickListener(this);
    }
    public void onClick(View v) {
        Intent i;

        if (v.getId() == R.id.map1) {
            i = new Intent(this, WhiteKnightActivity.class);
            startActivity(i);
        } else if (v.getId() == R.id.map2) {
            i = new Intent(this, LondonCamActivity.class);
            startActivity(i);
        } else if (v.getId() == R.id.map3) {
            i = new Intent(this, GreenlandsActivity.class);
            startActivity(i);

        }else {
                i = new Intent(this, CalendarActivity.class);
                startActivity(i);
        }
    }
}
