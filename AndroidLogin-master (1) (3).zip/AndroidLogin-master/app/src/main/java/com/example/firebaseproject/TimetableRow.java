package com.example.firebaseproject;

public class TimetableRow {
    String moduleName;
    String moduleLocation;
    String moduleTime;


    public TimetableRow(String moduleName, String moduleLocation, String moduleTime) {
        this.moduleName = moduleName;
        this.moduleLocation = moduleLocation;
        this.moduleTime = moduleTime;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getModuleLocation() {
        return moduleLocation;
    }

    public String getModuleTime() {
        return moduleTime;
    }
}
