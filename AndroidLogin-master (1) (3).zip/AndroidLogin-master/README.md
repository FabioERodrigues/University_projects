# Mobile Application for University student


##Student name - Fabio Rodrigues

##StudentID - 31016067

#This contains a student app with 4 features with the use of firebase.

*Feature 1 - Login and registration 
 *Use this login to sign in - email - Fabio15@gmail.com,  Password - FabioPassword11.

*Feature 2 - Personalised Timetable with to do list

*Feature 3 - Campus maps with google links

*Feature 4 - Personal Profile
