package finalRobotCoursework;

public class AvoidRobot extends ArenaItem { 
	private static final long serialVersionUID = 1L;
	private int score;

	
	public AvoidRobot() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param ix
	 * @param iy
	 * @param ir
	 */
	public AvoidRobot(double ix, double iy, double ir) {
		super(ix, iy, ir);
		score = 0;
		col = 's';
	}

	
	
	protected void checkItem(RobotArena R) {
		// TODO Auto-generated method stub
		if (R.checkHit(this)) score++;			// if been hit, then increase score
	 }
	/**
	 * draw Ball and display score
	 */
	public void drawItem(MyCanvas mc) {
		super.drawItem(mc);
		mc.showInt(x, y, score); // calls showint from mycanvas to display score
	}
	
	


	@Override
	protected void adjustItem() {
		// TODO Auto-generated method stub

	}
	
	protected String getStrType() {
		return "Avoid Robot";  // prints the name of item
	}

}
