package finalRobotCoursework;
import java.awt.event.MouseEvent;
import java.io.Serializable;

import javafx.animation.AnimationTimer;
import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.effect.BoxBlur;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.scene.text.TextAlignment;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import java.io.Serializable;


public class MyCanvas implements Serializable{
	private static final long serialVersionUID = 1L;

		int xCanvasSize = 512;				// constants for relevant sizes
		int yCanvasSize = 512;
	    transient GraphicsContext gc; 
	    Line Borders[]; // array for borders

	    /**
	     * onstructor sets up relevant Graphics context and size of canvas
	     * @param g
	     * @param cs
	     */
	    public MyCanvas(GraphicsContext g, int xcs, int ycs) {
	    	gc = g;
	    	xCanvasSize = xcs;
	    	yCanvasSize = ycs;
	    	Borders =new Line[7];
	    }
	    /**
	     * get size in x of canvas
	     * @return xsize
	     */
	    public int getXCanvasSize() {
	    	return xCanvasSize;
	    }
	    /**
	     * get size of xcanvas in y    
	     * @return ysize
	     */
	    public int getYCanvasSize() {
	    	return yCanvasSize;
	    }

	    /**
	     * clear the canvas
	     */
	    public void clearCanvas() {
			gc.clearRect(0,  0,  xCanvasSize,  yCanvasSize);		// clear canvas
	    }
	    
		/**
	     * drawIt ... draws object defined by given image at position and size
	     * @param i		image
	     * @param x		xposition	in range 0..1
	     * @param y
	     * @param sz	size
	     */
		public void drawIt (Image i, double x, double y, double sz) {
				// to draw centred at x,y, give top left position and x,y size
				// sizes/position in range 0..1, so scale to canvassize 
			gc.drawImage(i, xCanvasSize * (x - sz/2), yCanvasSize*(y - sz/2), xCanvasSize*sz, yCanvasSize*sz);
		}
		
		
//		public void drawLine(double x1, double y1, double x2, double y2) {
//	        Line myLine = new Line(x1, y1, x2, y2);
//	        myLine.drawLine(null, 3);
//	        
//	    }
		
		/** 
		 * function to convert char c to actual colour used
		 * @param c
		 * @return Color
		 */
		Color colFromChar (char c){
			Color ans = Color.BLACK;
			switch (c) {
			case 'y' :	ans = Color.YELLOW;
						break;
			case 'w' :	ans = Color.WHITE;
						break;
			case 'r' :	ans = Color.RED;
						break;
			case 'g' :	ans = Color.GREEN;
						break;
			case 'b' :	ans = Color.BLUE;
						break;
			case 'o' :	ans = Color.ORANGE;
						break;
			}
			return ans;
		}
		
		public void setFillColour (Color c) {
			gc.setFill(c);
		}
		/**
		 * show the ball at position x,y , radius r in colour defined by col
		 * @param x
		 * @param y
		 * @param rad
		 * @param col
		 */
		public void showCircle(double x, double y, double rad, char col) {
		 	setFillColour(colFromChar(col));									// set the fill colour
			gc.fillArc(x-rad, y-rad, rad*2, rad*2, 0, 360, ArcType.ROUND);	// fill circle
		}
		
		 public void drawBorders() {


		    	

		    	/**

		    	 * borders[0] = BOTTOM

		    	 * borders[1] = RIGHT

		    	 * borders[2] = TOP

		    	 * borders[3] = LEFT

		    	 */

		    	Borders[0] = new Line(0,0,xCanvasSize,0);
		    	Borders[1] = new Line(0,0,0,0);

		    	Borders[2] = new Line(xCanvasSize,0,xCanvasSize,yCanvasSize);
		    	Borders[3] = new Line(0,0,0,0);

		    	Borders[4] = new Line(0,yCanvasSize,xCanvasSize,yCanvasSize);
		    	Borders[5] = new Line(0,0,0,0);
		    	
		    	Borders[6] = new Line(0,0,0,yCanvasSize);
		    	
		    	

		    	

		    	for (Line l: Borders) // using for to to callline to draw

		    	{

		    		l.drawLine(this, 2);;

		    	}
		    	

		    }

		/**
		 * show circle in current colour atx,y size rad
		 * @param x
		 * @param y
		 * @param rad
		 */
		public void showCircle(double x, double y, double rad) {
			gc.fillArc(x-rad, y-rad, rad*2, rad*2, 0, 360, ArcType.ROUND);	// fill circle
		}
		
		
		
		
		public void showPacman(double x, double y, double rad, double angle) {
		    setFillColour(Color.YELLOW);  // Set the fill color to yellow for Pac-Man
		    gc.fillArc(x - rad, y - rad, rad * 2, rad * 2, angle / 2, 360 - angle, ArcType.ROUND); // draws the pacman usingg graphical context gc
		}
		
		
		
		
		public Line[] getBorder() {
	        return Borders; // call for borders to be accessed in other classes
	    }
	    
		
		
		public void clearArena(RobotArena ra) {
			 // Stop the timer
		   

			
			
			// Create a new arena with the same canvas size
		    RobotArena newArena = new RobotArena(getXCanvasSize(), getYCanvasSize(), null);

		    // Set the new arena in the RobotViewer (assuming RobotViewer has a reference to the arena)
		    // This assumes that RobotViewer has a method like setArena in its class
		    // Uncomment the line below if needed
		    // robotViewer.setArena(newArena);

		    // Clear the canvas
		    clearCanvas();

		    // Draw the new arena on the canvas
		    ra.drawArena(this);
		    
		    // Restart the timer
		    
		}
		
		public void showRectangle(double x, double y, double width, double height, char col) {

		    //setFillColour(colFromChar(col));            // set the fill color

		    //gc.fillRect(x - width / 2, y - height / 2, width, height);  // draw rectangle

			setFillColour(colFromChar(col)); // set the fill color

		    gc.setEffect(new BoxBlur());      // apply a BoxBlur effect for anti-aliasing

		    gc.fillRect(x - width / 2, y - height / 2, width, height); // draw rectangle

		    gc.setEffect(null);               // reset the effect after drawing the rectangle

		}
		
		
		/* * Show Text .. by writing string s at position x,y
		 * @param x
		 * @param y
		 * @param s
		 */
		public void showText (double x, double y, String s) {
			gc.setTextAlign(TextAlignment.CENTER);							// set horizontal alignment
			gc.setTextBaseline(VPos.CENTER);								// vertical
			gc.setFill(Color.WHITE);										// colour in white
			gc.fillText(s, x, y);						// print score as text
		}

		/**
		 * Show Int .. by writing int i at position x,y
		 * @param x
		 * @param y
		 * @param i
		 */
		public void showInt (double x, double y, int i) {
			showText (x, y, Integer.toString(i));
		}
		
	}


