package finalRobotCoursework;

import java.util.ArrayList;

public class WhiskerRobot extends Robot {
	private static final long serialVersionUID = 1L;
    private Line Whiskers[]; // declares whiskers array
    double whiskerLength; // sets up whiskerlength variable
    private double bAngle;

    public WhiskerRobot() {
        super();
       
       
    }

    public WhiskerRobot(double ix, double iy, double ir, double ia, double is) {
        super(ix, iy, ir, ia, is);
        Whiskers = new Line[2]; // sets and initialises whiskers array
        whiskerLength = 30; // sets whiskers length
        bAngle = ia;
        //initializeWhiskers();
    }

    protected void initializeWhiskers() {
       
    	// Calculates coordinates for the start and end points of the first whisker 
        // Calculates coordinates for the start and end points of the second whisker
    	 // sets the co-ordinates for  whiskers 

        Whiskers[0] = new Line(x + (rad * Math.cos(Math.toRadians(bAngle + 45))) , y + (rad * Math.sin(Math.toRadians(bAngle + 45))), x + ((rad+whiskerLength) * Math.cos(Math.toRadians(bAngle + 45))) , y +( (rad+whiskerLength) * Math.sin(Math.toRadians(bAngle + 45))));  // Adjust width as needed
        Whiskers[1] = new Line(x + (rad * Math.cos(Math.toRadians(bAngle - 45))) , y + (rad * Math.sin(Math.toRadians(bAngle - 45))),x + ((rad+whiskerLength) * Math.cos(Math.toRadians(bAngle - 45))) , y + ((rad+whiskerLength) * Math.sin(Math.toRadians(bAngle - 45))));  // Adjust width as needed
    }
    
    @Override 
    protected void checkItem(RobotArena ra) {

		bAngle = ra.CheckItemAngle(x, y, rad, bAngle, ItemID);
		
    }


    public void drawItem(MyCanvas mc) {
        super.drawItem(mc);
        initializeWhiskers(); // calls function the to be called for array
        // Draw the whiskers
        Whiskers[0].drawLine(mc, 2);   // uses co-ords to call drawline and set width to 1`
        Whiskers[1].drawLine(mc, 2);  
    }
    
    
    public Line[] getWhiskers() {
        return Whiskers; // this function allows whiskers array to be called in other classes
    }
    protected void initializeWheels() {
	    // Calculates the positions of the wheels relative to the robot's position and orientation
    	Line[] wheels = getWheels();
	    // Set the coordinates for the wheels
        wheels[0] = new Line(x + rad * Math.cos(Math.toRadians(bAngle + 45)) , y + rad * Math.sin(Math.toRadians(bAngle + 45)), x + rad * Math.cos(Math.toRadians(bAngle +135)) ,y + rad * Math.sin(Math.toRadians(bAngle +135)));  
	    wheels[1] = new Line(x + rad * Math.cos(Math.toRadians(bAngle -45)) , y + rad * Math.sin(Math.toRadians(bAngle - 45)), x + rad * Math.cos(Math.toRadians(bAngle - 135)), y + rad * Math.sin(Math.toRadians(bAngle - 135)));    
	    
      //  x + r*cos(a+45)
	 //   y + r*sin(a+45)
	}
    
    public double getAngle() {
    	
    	return this.bAngle;
    }
    
    
	@Override
	protected void adjustItem() {
		// TODO Auto-generated method stub
	    double bSpeed = getRobotSpeed();
		double radAngle = bAngle*Math.PI/180;		// put angle in radians
		x += bSpeed * Math.cos(radAngle);		// new X position
		y += bSpeed * Math.sin(radAngle);       // new y position
		


	}
	public double getRobotSpeed() {
		return bSpeed;
	}
	/*
	 * public void whiskerToWhiskerCollion() {
	 * 
	 * for (Line first : Whiskers) { for (Line wSecond: Whiskers) {
	 * 
	 * } } }
	 * 
	 */
    
    public void setAngleOnCollision(double angle) {
    	this.bAngle = angle;
    	
    }
    
    protected String getStrType() {
		return "Whisker Robot";
}
}