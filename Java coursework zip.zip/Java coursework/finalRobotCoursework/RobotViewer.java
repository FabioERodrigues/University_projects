package finalRobotCoursework;
import java.awt.Event;
import java.io.File;
import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;




/**
 * @author shsmchlr
 * Class with the GUI which depicts a ball running round an arena.
 
/**
 * @author shsmchlr Example with balls, paddles and targets in arena
 */
public class RobotViewer extends Application {
	private MyCanvas mc;
	private AnimationTimer timer; // timer used for animation
	private VBox rtPane; // vertical box for putting info
	private RobotArena arena; // to access Robot arena class
	private FileChooser fileChooser;                            // for selecting files to read/write
	

	/**
	 * function to show in a box ABout the programme
	 */
	private void showAbout() {
		Alert alert = new Alert(AlertType.INFORMATION); // define what box is
		alert.setTitle("About"); // say is About
		alert.setHeaderText(null);
		alert.setContentText("Robot Simulation by 31016067 \n - Add different types of robots & items below"
				+ " \n - Press shift + click on item = delete item"
				+ "\n - Select item to move by clicking on it "
				+ "\n - click new arena to remove items.");
		alert.showAndWait(); // show box and wait for user to close
		
		
	}
	   private void showMessage(String TStr, String CStr) {
           Alert alert = new Alert(AlertType.INFORMATION);
           alert.setTitle(TStr);
           alert.setHeaderText(null);
           alert.setContentText(CStr);

           alert.showAndWait();
   }
	   
	private void drawBorders() {
		
		mc.drawBorders(); //uses mycanvas to draw borders
	}

	/**
	 * set up the mouse event - when mouse pressed, put ball there
	 * 
	 * @param canvas
	 */
	
	
	


	void setMouseEvents(Canvas canvas) {
		canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, // for MOUSE PRESSED event
				new EventHandler<MouseEvent>() {
					@Override // sets upmouse event
					public void handle(MouseEvent e) {
						arena.setObstacle(e.getX(), e.getY()); 
						drawWorld(); // redraw world
						drawStatus();
					}
				}); 
		
//		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
//		    @Override
//		    public void handle(KeyEvent event) {
//		        // Get the code of the pressed key
//		        int keyCode = event.getCode().getCode();
//
//		        // Call the control method in the arena object
//		        arena.control(keyCode);
//		    }
//		});
		
		
		
		
		
		
		
		 canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
		        double mouseX = event.getX();
		        double mouseY = event.getY();

		        // Check if any item is selected
		        for (ArenaItem item : arena.getItemsArr()) {
		            if (item.contains(mouseX, mouseY)) {
		                arena.setSelectedItem(item);
		                break;
		            }
		        }
		    });

		    canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
		        if (arena.isItemSelected()) {
		            double mouseX = event.getX(); // gets x and y and assigns tp mousex and mousey 
		            double mouseY = event.getY();

		            // Update the position of the selected item
		            arena.setSelectedItemPosition(mouseX, mouseY);

		            // Redraw the arena
		            mc.clearCanvas();
		            arena.drawArena(mc);
		        }
		    });
		    
		    canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
		        if (event.isShiftDown()) { // if shift is downand u click the item it removes item
		            removeSelectedItem();
		        } else {
		           
		        }
		    });
		    
		    
		 

	}

	
	// function for removing +item 
	private void removeSelectedItem() {
        ArenaItem selectedItem = arena.getSelectedItem();
        if (selectedItem != null) {
            int itemId = selectedItem.getID();
            arena.removeItemById(itemId);
            mc.clearCanvas();
            drawWorld();
            drawBorders();
            drawStatus();
        }
    }
	
	
	/**
	 * set up the menu of commands for the GUI
	 * 
	 * @return the menu bar
	 */

	
	MenuBar setMenu() {
		 fileChooser = new FileChooser();
		 FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Robot Files", "*.cfg"); 
		 fileChooser.getExtensionFilters().add(extFilter);
		 fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
		MenuBar menuBar = new MenuBar(); // create main menu

		Menu mFile = new Menu("File"); // add File main menu
		MenuItem mExit = new MenuItem("Exit"); // whose sub menu has Exit
		mExit.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent t) { // action on exit is
				timer.stop(); // stop timer
				System.exit(0); // exit program
			}
		});
		
		 MenuItem mSave = new MenuItem("Save");                          // save option
	        mSave.setOnAction(new EventHandler<ActionEvent>() {
	            public void handle(ActionEvent t) {                         // action on save
	                timer.stop();                                           // stop timer
	                File selectedFile = fileChooser.showSaveDialog(null);   // user selects file
	                if (selectedFile != null) {
	                    if (arena.saveFile(selectedFile.getName()) > 0)    // save the arena
	                        showMessage("Error", "Could not save file");
	                    else showMessage ("Message", "File saved ok");
	                }   
	            }
	        });
		
		
		
	        MenuItem mLoad = new MenuItem("Load");              // whose sub menu has Exit
	        mLoad.setOnAction(new EventHandler<ActionEvent>() {
	            public void handle(ActionEvent t) {             // action on exit
	                timer.stop();                               // stop timer
	                File selectedFile = fileChooser.showOpenDialog(null);       // ask user for file name
	                if (selectedFile != null) {                                 // if selected
	                    if (arena.loadFile(selectedFile.getName()) > 0)     // load try to load
	                        showMessage("Error", "Could not load file");
	                    else {
	                        showMessage ("Message", "File loaded ok");
	                        drawWorld();                                        // redraw the world
	                        drawStatus();                                       // indicate where balls are
	                    }
	                }   
	            }
	        });
		
	
		mFile.getItems().addAll(mLoad, mSave, mExit);// add exit to File menu
		
		

		Menu mHelp = new Menu("Help"); // create Help menu
		MenuItem mAbout = new MenuItem("About"); // add About sub men item
		mAbout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				showAbout(); // and its action to print about
			}
		});
		mHelp.getItems().addAll(mAbout); // add About to Help main item

		
	
	

	Menu mMove = new Menu("Control"); // create Help menu
	
	MenuItem mUp = new MenuItem("Up"); // add About sub men item
	mUp.setOnAction(new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent actionEvent) {
			arena.moveUp();
		}
	});
	
	
	
	MenuItem mDown = new MenuItem("Down"); // add About sub men item
	mDown.setOnAction(new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent actionEvent) {
			arena.moveDown();
		}
	});
	
	
	
	MenuItem mLeft = new MenuItem("Left"); // add About sub men item
	mLeft.setOnAction(new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent actionEvent) {
			arena.moveLeft();
		}
	});
	
	

	MenuItem mRight = new MenuItem("Right"); // add About sub men item
	mRight .setOnAction(new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent actionEvent) {
			arena.moveRight();
		}
	});
	
	mMove.getItems().addAll(mUp, mDown, mLeft, mRight); // add About to Help main item

	menuBar.getMenus().addAll(mFile, mHelp, mMove); // set main menu with File, Help
	
	
	return menuBar; // return the menu
}

	/**
	 * set up the horizontal box for the bottom with relevant buttons
	 * 
	 * @return
	 */
	private HBox setButtons() {
		Button btnStart = new Button("Start"); // create button for starting
		btnStart.setOnAction(new EventHandler<ActionEvent>() { // now define event when it is pressed
			@Override
			public void handle(ActionEvent event) {
				timer.start(); // its action is to start the timer
			}
		});

		Button btnStop = new Button("Pause"); // now button for stop
		btnStop.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				timer.stop(); // and its action to stop the timer
			}
		});
		
		Button btnClear = new Button("New Arena"); // now button for stop
		btnClear.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				 mc.clearCanvas(); // Clear the arena and draw the new one
				 arena.clearItemArena();
			     drawBorders();
			     
				
				
				

			}
		});

		Button btnAdd = new Button("Robot"); // now button for stop
		btnAdd.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				arena.addRobot(); // and adds robot
				drawWorld();
				drawBorders();
				drawStatus();
				
			}
		});

		Button btnAdd2 = new Button("Avoid Robot"); // now button for stop
		btnAdd2.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				arena.addAvoidRobot(); // adds avoid robot
				drawWorld();
				drawBorders();
				drawStatus();
				

			}
		});
		
		
		/*
		 * Button btnAdd3 = new Button("Control Robot"); // now button for stop
		 * btnAdd3.setOnAction(new EventHandler<ActionEvent>() {
		 * 
		 * @Override public void handle(ActionEvent event) { arena.addControlRobot();
		 * drawWorld(); drawBorders(); drawStatus();
		 * 
		 * 
		 * } });
		 */

		Button btnAdd4 = new Button("Obstacle"); // now button for stop
		btnAdd4.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				arena.addObstacle();  // adds obstacle
				drawWorld();
				drawBorders();
				drawStatus();
				

			}
		});
		
		
		
		Button btnAdd5 = new Button("PacMan"); // now button for stop
		btnAdd5.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				arena.addPacMan(); //  // adds pacman
				drawWorld();
				drawBorders();
				drawStatus();
				
			}
		});
		
		
		
		Button btnAdd6 = new Button("Whisker"); // now button for stop
		btnAdd6.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				arena.addWhiskerRobot(); //  adds whiskerrobot
				drawWorld();
				drawBorders();
				drawStatus();
				
			}
		});
		
		
		
		
		Button btnAdd7 = new Button("Beams"); // now button for stop
		btnAdd7.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				arena.addBeamsRobot(); //  // adds beam robot
				
				drawWorld();
				drawBorders();
				drawStatus();
				
			}
		});
		
		
		Button btnAdd8 = new Button("Slow motion"); // now button for stop
		btnAdd8.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
			
				arena.slowMotion();
				drawWorld();
				drawBorders();
				drawStatus();
				
			}
		});
		

		// adds all the buuton to hbox here
		return new HBox(new Label("Run: "), btnStart, btnStop, new Label("Add: "),btnClear, btnAdd8, btnAdd, btnAdd2,  btnAdd4, btnAdd5, btnAdd6, btnAdd7);
	}
	
	
	/**
	 * Show the score .. by writing it at position x,y
	 * 
	 * @param x
	 * @param y
	 * @param score
	 */
	public void showScore(double x, double y, int score) {
		mc.showText(x, y, Integer.toString(score)); // score for avoid robot
	}

	/**
	 * draw the world with Items in it
	 */
	public void drawWorld() {
		mc.clearCanvas(); // set beige colour
		arena.drawArena(mc);
	}

	/**
	 * show where items is, in pane on right
	 */
	public void drawStatus() {
		rtPane.getChildren().clear(); // clear rtpane
		ArrayList<String> allBs = arena.describeAll();
		for (String s : allBs) {
			Label l = new Label(s); // turn description into a label
			rtPane.getChildren().add(l); // add label
		}
	}
	
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see javafx.application.Application#start(javafx.stage.Stage)
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("RJMs attempt at Moving Ball");
		BorderPane bp = new BorderPane();
		bp.setPadding(new Insets(10, 20, 10, 20));

		bp.setTop(setMenu()); // put menu at the top

		Group root = new Group(); // create group with canvas
		Canvas canvas = new Canvas(500, 400);
		root.getChildren().add(canvas);
		bp.setLeft(root); // load canvas to left area

		mc = new MyCanvas(canvas.getGraphicsContext2D(), 500, 400);

		setMouseEvents(canvas); // set up mouse events
		
		
	

		arena = new RobotArena(500, 400, mc); // set up arena
		drawWorld();
	   drawBorders();
	   
	   
	   
	   
	   
	  

		timer = new AnimationTimer() { // set up timer
			public void handle(long currentNanoTime) { // and its action when on
				arena.checkArenaItems(); // check the angle of all balls
				arena.adjustArenaItems(); // move all balls
				arena.whiskerCollision();
				arena.beamCollision();
				drawWorld(); // redraw the world
				drawBorders();
			
				
			}
		};

		rtPane = new VBox(); // set vBox on right to list items
		rtPane.setAlignment(Pos.TOP_LEFT); // set alignment
		rtPane.setPadding(new Insets(5, 75, 75, 5)); // padding
		bp.setRight(rtPane); // add rtPane to borderpane right

		bp.setBottom(setButtons()); // set bottom pane with buttons

		Scene scene = new Scene(bp, 700, 600); // set overall scene
		bp.prefHeightProperty().bind(scene.heightProperty());
		bp.prefWidthProperty().bind(scene.widthProperty());
		
//		scene.setOnKeyPressed(event -> {
//			System.out.println("Key pressed: " + event.getCode());
//		    KeyCode keyCode = event.getCode();
//		//    arena.control(keyCode);
//		    event.consume();
		   

		//});
		
	



		primaryStage.setScene(scene);
		primaryStage.show();

	}
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Application.launch(args); // launch the GUI

	}

}