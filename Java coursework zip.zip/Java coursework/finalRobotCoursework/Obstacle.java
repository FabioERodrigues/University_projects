package finalRobotCoursework;

public class Obstacle extends ArenaItem {
	 private static final long serialVersionUID = 1L;
	
	public Obstacle() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param ix
	 * @param iy
	 * @param ir
	 */
	public Obstacle(double ix, double iy, double ir) {
		super(ix, iy, ir);
		col = 'q';
	}

	
	@Override
	protected void checkItem(RobotArena R) {
		// nowt to do

	}

	
	@Override
	protected void adjustItem() {
		// nowt to do

	}
	
	

	protected String getStrType() {
		return "Obstacle";
	}	

}