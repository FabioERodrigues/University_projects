package finalRobotCoursework;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import javafx.scene.input.KeyCode;

public class RobotArena implements Serializable {
	private static final long serialVersionUID = 1L;
	double xSize, ySize; // size of arena
	private ArrayList<ArenaItem> ItemsArr; // array list of all ArenaItems in arena
	MyCanvas mc;

	/**
	 * construct an arena
	 */
	RobotArena() {
		this(500, 400, null); // default size
	}

	RobotArena(double xS, double yS, MyCanvas mc) {
		xSize = xS;
		ySize = yS;
	
		ItemsArr = new ArrayList<ArenaItem>(); // initialize ItemsArr
		//ItemsArr.add(new FastZone(0, 0, 20));
		ItemsArr.add(new BeamsRobot(xS / 2, yS / 2, 10, 45, 0.5));
		ItemsArr.add(new PacMan(50, 50, 10, 0, 0.5, 90));
		ItemsArr.add(new AvoidRobot(xS / 2, 100, 15));
		ItemsArr.add(new WhiskerRobot(100, yS / 2, 10, 45, 0.5));
		ItemsArr.add(new Robot(xS / 2, 300, 10, 45, 0.5));
		ItemsArr.add(new ControlRobot(200, 400, 5));
		
		this.mc = mc;
	}

	public void clearItemArena() {
		ItemsArr.clear();
	}

	public double getXSize() {
		return xSize;
	}

	/**
	 * return arena size in y direction
	 * 
	 * @return
	 */
	public double getYSize() {
		return ySize;
	}
	
	
	

	/**
	 * draw all ArenaItems in the arena into interface bi
	 * 
	 * @param bi
	 */
	public void drawArena(MyCanvas mc) {
		for (ArenaItem i : ItemsArr)
			i.drawItem(mc); // draw all ArenaItems
	}

	/**
	 * check all ArenaItems .. see if need to change angle of moving ArenaItems, etc
	 */
	public void checkArenaItems() {
		for (ArenaItem i : ItemsArr)
			i.checkItem(this);

	}

	/**
	 * adjust all ArenaItems .. move any moving ones
	 */
	public void adjustArenaItems() {
		for (ArenaItem i : ItemsArr)
			i.adjustItem();

		// WhiskersSensor(line, mc);

	}

	public void setObstacle(double x, double y) {
		for (ArenaItem o : ItemsArr)
			if (o instanceof ControlRobot)
				o.setXY(x, y);
	}

	public int saveFile(String fname) {
		int status = 0;
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(fname); // setup
			ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);
			outputStream.writeObject(this); // write arena and contents
			outputStream.close(); // close
			fileOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			status = 1;
		}
		return status;
	}

	public ArrayList<String> describeAll() {
		ArrayList<String> ans = new ArrayList<String>(); // set up empty arraylist
		for (ArenaItem i : ItemsArr)
			ans.add(i.toString()); // add string defining each ArenaItem
		return ans; // return string list
	}

	public int loadFile(String fname) {
		int status = 0;
		ItemsArr.clear();
		try {
			FileInputStream fileInputStream = new FileInputStream(fname); // set up input stream
			ObjectInputStream inputStream = new ObjectInputStream(fileInputStream); // and file
			RobotArena A = (RobotArena) inputStream.readObject(); // read whole object
			this.xSize = A.xSize; // load into arena
			this.ySize = A.ySize;
			this.ItemsArr = A.ItemsArr;
			inputStream.close(); // close...
			fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			status = 1;
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
			status = 2;
		}
		return status;
	}

	public void addRobot() {

		Random rand = new Random(); // random function
		double newX = rand.nextDouble() * 500; // places the robot in a random position x till the range if 500
		double newY = rand.nextDouble() * 400; // places the robot in a random position y till the range if 400
		double newRad = 10; // sets radius
		double newBangle = 0; // start angle
		double newbSpeed = 0.5; // speed
		ItemsArr.add(new Robot(newX, newY, newRad, newBangle, newbSpeed)); // adds new item using ther above value
	}



	public void addWhiskerRobot() {

		Random rand = new Random();
		double newX = rand.nextDouble() * 500; // places the robot in a random position x till the range if 500
		double newY = rand.nextDouble() * 400; // places the robot in a random position y till the range if 400
		double newRad = 10; // sets radius
		double newBangle = 0; // start angle
		double newbSpeed = 0.5; // speed
		ItemsArr.add(new WhiskerRobot(newX, newY, newRad, newBangle, newbSpeed));// adds new item using ther above value
	}

	public void addBeamsRobot() {

		Random rand = new Random();
		double newX = rand.nextDouble() * 500; // places the robot in a random position x till the range if 500
		double newY = rand.nextDouble() * 400; // places the robot in a random position y till the range if 400
		double newRad = 10; // sets radius
		double newBangle = rand.nextDouble() * 360; // start angle
		double newbSpeed = 0.8; // speed
		ItemsArr.add(new BeamsRobot(newX, newY, newRad, newBangle, newbSpeed));// adds new item using ther above value
	}

	public void addAvoidRobot() {

		Random rand = new Random();
		double newX = rand.nextDouble() * 500; // places the robot in a random position x till the range if 500
		double newY = rand.nextDouble() * 400; // places the robot in a random position y till the range if 400
		double newRad = 15; // sets radius
		ItemsArr.add(new AvoidRobot(newX, newY, newRad));// adds new item using ther above value
	}

	public void addObstacle() {

		Random rand = new Random();
		double newX = rand.nextDouble() * 500; // places the robot in a random position x till the range if 500
		double newY = rand.nextDouble() * 400; // places the robot in a random position y till the range if 400
		double newRad = 5 + rand.nextDouble() * (20 - 5);
		; // generates a num in the range of 5 to 20 for radius so obstacle can be of
			// diffferent size
		ItemsArr.add(new Obstacle(newX, newY, newRad));// adds new item using ther above value
	}

	public void addPacMan() {

		Random rand = new Random();
		double newX = rand.nextDouble() * 500; // places the robot in a random position x till the range if 500
		double newY = rand.nextDouble() * 400; // places the robot in a random position y till the range if 400
		double newRad = 5; // sets radius
		double newBangle = 0; // start angle
		double newbSpeed = 0.5; // speed
		double newMouthAngle = 90; // sets pacman mouth angle
		ItemsArr.add(new PacMan(newX, newY, newRad, newBangle, newbSpeed, newMouthAngle));// adds new item using ther
																							// above value
	}
	
	


	// attempt at whiskerSensors
	public void whiskerCollision() {
		Line[] bordersArr = mc.getBorder();
		Line[] whiskerArr;// = wr.getWhiskerPos();
		// //char = ' '; // Initialize col variable
		double angleToAdd = 45; // choose ur angle see what works best 0 -360

		for (ArenaItem i : ItemsArr) {
			if (i instanceof WhiskerRobot) {
				whiskerArr = ((WhiskerRobot) i).getWhiskers();
				for (Line w : whiskerArr) {
					for (int num = 0; num < 7; num++) {
						// if //(bordersArr[num].findintersection(w)){
						if (bordersArr[num].findintersection(w)) {

							((WhiskerRobot) i).setAngleOnCollision(((WhiskerRobot) i).getAngle() + angleToAdd);

						}

					}
					// for all 4 borders check intersection

					//

					// Check for collisions of whiskers with whiskers

					for (ArenaItem other : ItemsArr) {

						// only do this if other is a whisker robot

						if (i != other && other instanceof WhiskerRobot) {

							Line[] otherWhiskers = ((WhiskerRobot) other).getWhiskers();

							for (Line otherw : otherWhiskers) {

//						
								if (w.findintersection(otherw)) {

									// Whiskers collide, adjust angles as needed

									((WhiskerRobot) i).setAngleOnCollision(((WhiskerRobot) i).getAngle() + angleToAdd);

									((WhiskerRobot) other)
											.setAngleOnCollision(((WhiskerRobot) other).getAngle() + angleToAdd);
								}

							}

						}

					}

					// Check for intersections with other items

					for (ArenaItem other : ItemsArr) {

						if (other != i) { // Check only against robots && other instanceof Robot

							// double distance = w.distanceFrom(other.getX(), other.getY());
							double distance = w.distanceFrom(other.getX(), other.getY());
							if (distance < other.getRad()) {

								// Whisker detects the other robot, change the angle

								((WhiskerRobot) i).setAngleOnCollision(((WhiskerRobot) i).getAngle() + angleToAdd);

							}

						}

					}

				}

			}

		}

	}

	public void beamCollision() {

		Line[] bordersArr = mc.getBorder();
		Line[] beamArr; // array to store beams positions
		double angleToAdd = 45;

		for (ArenaItem item : ItemsArr) {
			if (item instanceof BeamsRobot) {
				beamArr = ((BeamsRobot) item).getBeamsArr();
				for (Line b : beamArr) {
					// for all 4 borders check intersection
					if (bordersArr[0].findintersection(b)) {
			
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}
					if (bordersArr[1].findintersection(b)) {
						
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}
					if (bordersArr[2].findintersection(b)) {
						
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}
					if (bordersArr[3].findintersection(b)) {
						
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}
					if (bordersArr[4].findintersection(b)) {
					
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}
					if (bordersArr[5].findintersection(b)) {
						
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}
					if (bordersArr[6].findintersection(b)) {
						
						((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

					}

					// Check for collisions of whiskers with whiskers

					for (ArenaItem other : ItemsArr) {
						if (item != other && other instanceof BeamsRobot) {

							// only do this if other is a whisker robot

							Line[] otherBeams = ((BeamsRobot) other).getBeamsArr();

							for (Line otherb : otherBeams) {

								if (b.findintersection(otherb))

								{
									// Whiskers collide, adjust angles as needed
									((BeamsRobot) item)
											.setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

									((BeamsRobot) other)
											.setAngleOnCollision(((BeamsRobot) other).getAngle() + angleToAdd);

								}

							}

						}

					}

					// Check for intersections with other items

					for (ArenaItem other : ItemsArr) {

						if (other != item) { // Check only against robots && other instanceof Robot
							double distance = b.distanceFrom(other.getX(), other.getY());
							if (distance < other.getRad()) {
								// Whisker detects the other robot, change the angle
								((BeamsRobot) item).setAngleOnCollision(((BeamsRobot) item).getAngle() + angleToAdd);

							}

						}

					}

				}

			}

		}

	}

	public void slowMotion() {
		for (ArenaItem i : ItemsArr) {
			if (i instanceof Robot) {
				((Robot) i).bSpeed = 0.15; // reduces the speed of the robot and sub classes in it

			}
		}

	}

	public void moveUp() {

		for (ArenaItem i : ItemsArr) {
			if (i instanceof PacMan) {
				((PacMan) i).bAngle = -90;

				// reduces the speed of the robot and sub classes in it

			}
		}

	}

	public void moveDown() {

		for (ArenaItem i : ItemsArr) {
			if (i instanceof PacMan) {
				((PacMan) i).bAngle += 180;

				// reduces the speed of the robot and sub classes in it

			}
		}

	}

	public void moveRight() {

		for (ArenaItem i : ItemsArr) {
			if (i instanceof PacMan) {
				((PacMan) i).bAngle = 0;
				;

				// reduces the speed of the robot and sub classes in it

			}
		}

	}

	public void moveLeft() {

		for (ArenaItem i : ItemsArr) {
			if (i instanceof PacMan) {
				((PacMan) i).bAngle = 180;
				;

				// reduces the speed of the robot and sub classes in it

			}
		}

	}
//
//	public void control(KeyCode keyCode) {
//		for (ArenaItem i : ItemsArr) {
//			if (i instanceof PacMan) {
//				switch (keyCode) {
//				case UP:
//					((PacMan) i).bAngle = 270;
//					break;
//				case DOWN:
//					((PacMan) i).bAngle = 90;
//					break;
//				case LEFT:
//					((PacMan) i).bAngle = 180;
//					break;
//				case RIGHT:
//					((PacMan) i).bAngle = 0; // move to the right
//					break;
//				// You can add more cases for additional controls if needed
//				default:
//					break;
//				}
//			}
//
//		}
//	}



	// used for saving and loading files
	private ArenaItem selectedItem;

	public ArrayList<ArenaItem> getItemsArr() {
		return ItemsArr;
	}

	public ArenaItem getSelectedItem() {
		return selectedItem;
	}

	public void setSelectedItem(ArenaItem selectedItem) {
		this.selectedItem = selectedItem;
	}

	public void setSelectedItemPosition(double x, double y) {
		if (selectedItem != null) {
			selectedItem.setXY(x, y);
		}
	}

	public boolean isItemSelected() {
		return selectedItem != null;
	}

	public void removeItemById(int itemId) {
		ItemsArr.removeIf(item -> item.getID() == itemId);
	}

	/*
	 * public void addObstacle() { ItemsArr.add(new Obstacle(xSize/2, ySize/2, 20));
	 * }
	 */

	public boolean checkHit(ArenaItem target) {
		boolean ans = false;
		for (ArenaItem b : ItemsArr)
			if (b instanceof Robot && b.hitting(target))
				ans = true;

		return ans;
	}

	public double CheckItemAngle(double x, double y, double rad, double ang, int notID) {
		double ans = ang;
		if (x < rad || x > xSize - rad)
			ans = 180 - ans;
		// if ArenaItem hit (tried to go through) left or right walls, set mirror angle,
		// being 180-angle
		if (y < rad || y > ySize - rad)
			ans = -ans;
		// if try to go off top or bottom, set mirror angle

		for (ArenaItem i : ItemsArr)
			if (i.getID() != notID && i.hitting(x, y, rad))
				ans = 180 * Math.atan2(y - i.getY(), x - i.getX()) / Math.PI;
		// check all ArenaItems except one with given id
		// if hitting, return angle between the other ArenaItem and this one.

		return ans; // return the angle
	}

}