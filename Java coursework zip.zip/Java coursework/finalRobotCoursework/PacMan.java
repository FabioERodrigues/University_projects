package finalRobotCoursework;

import java.util.Map;

import javafx.scene.input.KeyCode;

public class PacMan extends Robot {
	private static final long serialVersionUID = 1L;
	private double pacmanMouthAngle; //sets variable
	
	public PacMan() {
		super();
		
	}
	
	
	public PacMan(double ix, double iy, double ir, double ia, double is, double pm) {
        super(ix, iy, ir, ia, is);
        pacmanMouthAngle = pm; //initialize variable
        
        }

	protected void adjustItem() {
			
		double xSize = 500;  // size of canvas x
		double  ySize = 400; // size of canvas y
		
	    double radAngle = bAngle * Math.PI / 180; // Convert angle to radians

	    // Calculate new position
	    double newX = x + bSpeed * Math.cos(radAngle);
	    double newY = y + bSpeed * Math.sin(radAngle);

	    // Check if the new position is within the boundaries
	    if (newX >= (rad*2+5) && newX <= xSize - (rad*2+5) && newY >= (rad*5) && newY <= ySize - (rad*2+5)) {
	        x = newX;
	        y = newY;
	    } else {
	        // If the new position goes beyond the boundaries, adjust the angle and keep it in a loop
	        bAngle += 90; // Rotate the robot by 90 degrees
	        bAngle %= 360; // Ensure the angle is within [0, 360)

	        // Update position based on the new angle
	        x += bSpeed * Math.cos(bAngle * Math.PI / 180);
	        y += bSpeed * Math.sin(bAngle * Math.PI / 180);
	    }

	    
	}
	
	
	public void drawItem(MyCanvas mc) {
		mc.showPacman(super.x, super.y, 20, pacmanMouthAngle);
		
	}
	
	
	
		protected String getStrType() {
			return "PacMan";

		 
		
	}
}
