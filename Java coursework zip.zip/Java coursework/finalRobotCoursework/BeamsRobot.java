package finalRobotCoursework;

public class BeamsRobot extends Robot {
	private static final long serialVersionUID = 1L;
	private Line Beams[]; // setup beams array
	double beamsLength; // beamslength variable
	double bAngle;



    public BeamsRobot() {
    	super();
    }
    
    
    public BeamsRobot(double ix, double iy, double ir, double ia, double is) {
    	super(ix, iy, ir, ia, is);
    	Beams = new Line [6];// initialize array
    	beamsLength = 33;    	
    	bAngle = ia;
    }
    
    

    
    @Override
	 protected void checkItem(RobotArena ra) {
	        bAngle = ra.CheckItemAngle(x, y, rad, bAngle, ItemID);
	        
	 }
    
    @Override
    protected void adjustItem() {
        // convert angle from degrees to radians
        double radAngle = bAngle * (Math.PI / 180);
        double rSpeed = getRobotSpeed();
        // update the x and y pos for the robot to move
        x += rSpeed * Math.cos(radAngle);
        y += rSpeed * Math.sin(radAngle);
    }
    
    
    
    public Line[] initialiseBeams() {
        // initialise the beams represented as 5 lines
     
        Beams[0] = new Line(x + (rad * Math.cos(Math.toRadians(bAngle + 45))), y + (rad * Math.sin(Math.toRadians(bAngle + 45))), x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle + 45))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle + 45))));
        Beams[1] = new Line(x + (rad * Math.cos(Math.toRadians(bAngle + 17))), y + (rad * Math.sin(Math.toRadians(bAngle + 17))), x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle + 17))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle + 17))));
        Beams[2] = new Line(x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle + 45))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle + 45))), x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle + 17))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle + 17))));
        Beams[3] = new Line(x + (rad * Math.cos(Math.toRadians(bAngle - 45))), y + (rad * Math.sin(Math.toRadians(bAngle - 45))), x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle - 45))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle - 45))));
        Beams[4] = new Line(x + (rad * Math.cos(Math.toRadians(bAngle - 17))), y + (rad * Math.sin(Math.toRadians(bAngle - 17))), x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle - 17))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle - 17))));
        Beams[5] = new Line(x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle - 45))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle - 45))), x + ((rad + beamsLength) * Math.cos(Math.toRadians(bAngle - 17))), y + ((rad + beamsLength) * Math.sin(Math.toRadians(bAngle - 17))));
        return Beams;
    }
	
	 public void drawItem(MyCanvas mc) {
	        super.drawItem(mc);
	        initialiseBeams();  // calls function the called for array
	        
	        for (Line w: Beams) {
	            w.drawLine(mc, 2);
	        }
	 }
	 
	 public Line[] getBeamsArr() {
	        return this.Beams; // to call beams array
	    }
	 
	 
	 
	 
	  protected void initializeWheels() {
		    // Calculates the positions of the wheels relative to the robot's position and orientation
	    	Line[] wheels = getWheels();
		    // Set the coordinates for the wheels
	        wheels[0] = new Line(x + rad * Math.cos(Math.toRadians(bAngle + 45)) , y + rad * Math.sin(Math.toRadians(bAngle + 45)), x + rad * Math.cos(Math.toRadians(bAngle +135)) ,y + rad * Math.sin(Math.toRadians(bAngle +135)));  
		    wheels[1] = new Line(x + rad * Math.cos(Math.toRadians(bAngle -45)) , y + rad * Math.sin(Math.toRadians(bAngle - 45)), x + rad * Math.cos(Math.toRadians(bAngle - 135)), y + rad * Math.sin(Math.toRadians(bAngle - 135)));    
		    
	      //  x + r*cos(a+45)
		 //   y + r*sin(a+45)
		}
	 

	    
	    
		/*
		 * public void whiskerToWhiskerCollion() {
		 * 
		 * for (Line first : Whiskers) { for (Line wSecond: Whiskers) {
		 * 
		 * } } }
		 * 
		 */
	    
	    public void setAngleOnCollision(double angle) {
	    	this.bAngle = angle; 
	    	
	    }
	 protected String getStrType() {
			return "Beams Robot";
	 
	 }
	 }
