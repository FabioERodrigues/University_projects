package finalRobotCoursework;

public class Robot extends ArenaItem {
	private static final long serialVersionUID = 1L;
	protected double bAngle, bSpeed;	//variables for bAngle and speed
	///private double rectangleWidth;  // Width of the rectangle
    //private double rectangleHeight; // Height of the rectangle
    private Line Wheels[]; // array 
    
	
	public Robot() {
		super();
		
	}
	/**
	 * 
	 * @param ix -x
	 * @param iy
	 * @param ir
	 * @param ia
	 * @param is
	 */
	public Robot(double ix, double iy, double ir, double ia, double is) {
		super(ix, iy, ir);
		bAngle = ia; // initialize bAngle
		bSpeed = is; // initialize  bspeed
		Wheels=new Line[2]; // initialize array
		initializeWheels(); // 

		
	}
	 
	@Override
	protected void checkItem(RobotArena R) {
		// TODO Auto-generated method stub
		bAngle = R.CheckItemAngle(x, y, rad, bAngle, ItemID);

	} 
	
	protected void initializeWheels() {
	    // Calculates the positions of the wheels relative to the robot's position and orientation

	    // Set the coordinates for the wheels
        Wheels[0] = new Line(x + rad * Math.cos(Math.toRadians(bAngle + 45)) , y + rad * Math.sin(Math.toRadians(bAngle + 45)), x + rad * Math.cos(Math.toRadians(bAngle +135)) ,y + rad * Math.sin(Math.toRadians(bAngle +135)));  
	    Wheels[1] = new Line(x + rad * Math.cos(Math.toRadians(bAngle -45)) , y + rad * Math.sin(Math.toRadians(bAngle - 45)), x + rad * Math.cos(Math.toRadians(bAngle - 135)), y + rad * Math.sin(Math.toRadians(bAngle - 135)));    
	    
      //  x + r*cos(a+45)
	 //   y + r*sin(a+45)
	}


	@Override
	protected void adjustItem() {
		// TODO Auto-generated method stub
		double radAngle = bAngle*Math.PI/180;		// put angle in radians
		x += bSpeed * Math.cos(radAngle);		// new X position
		y += bSpeed * Math.sin(radAngle);       // new y position
		


	}
	
	public void drawItem(MyCanvas mc) {
		super.drawItem(mc);
		initializeWheels(); //calls initializeWheels
	
		Wheels[0].drawLine(mc, 5); // calls array and then wheels from Line class to draw wheels on robot
		Wheels[1].drawLine(mc, 5);
		
		}
	
	
	public void setX(double newX) {
	    x = newX;
	}
	
	public void setY(double newY) {
	    y = newY;
	}
	
	public Line[] getWheels() {
		return Wheels;
	}
	
	


	  public double getAngle() {
	    	
	    	return this.bAngle;
	    }
	  


	
	public double getRobotSpeed() {
		return bSpeed;
	}
	
	protected String getStrType() {
		return "Robot";

}

	

}