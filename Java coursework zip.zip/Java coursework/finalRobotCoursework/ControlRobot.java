package finalRobotCoursework;

public class ControlRobot extends ArenaItem {
	 private static final long serialVersionUID = 1L;
	
	
	public ControlRobot() {
		super();
	}
	
	
	
	public ControlRobot(double ix, double iy, double ir) {
		super(ix, iy, ir);
		col = 'b';
		
	} 
		// TODO Auto-generated constructor stub
	@Override
	protected void checkItem(RobotArena R) {
		// TODO Auto-generated method stub

	}
	public void drawItem(MyCanvas mc) {

		super.drawItem(mc);
		//mc.showInt(x, y, score);
	}
	

	@Override
	protected void adjustItem() {
		// TODO Auto-generated method stub

	}
	protected String getStrType() {
		return "Control Robot";
	}
	
	
	
	



	//@Override
	//protected void wheels(MyCanvas mc) {
	//	// TODO Auto-generated method stub}	
	
}

