package finalRobotCoursework;

import java.io.Serializable;
import java.util.Random;

public abstract class ArenaItem implements Serializable{
	private static final long serialVersionUID = 1L;
	protected double x, y, rad;						// position and size of item
	protected char col;								// used to set colour
	static int ItemCounter = 0;						// used to give each item a unique identifier
	protected int ItemID;							// unique identifier for item

	ArenaItem() {
		this(100, 100, 10); // values for x, y, and radius
	}
	
	ArenaItem (double ix, double iy, double ir) {
		x = ix;
		y = iy;
		rad = ir;
		ItemID = ItemCounter++;			// set the identifier and increment class static
		col = 'r';      // default color red
	}
	
	
	public double getX() { return x; } // return x
	/**
	 * return y position
	 * @return
	 */
	public double getY() { return y; } // return y
	/**
	 * return radius of item
	 * @return
	 */
	public double getRad() { return rad; } // return radius 
	/** 
	 * set the item at position nx,ny
	 * @param nx
	 * @param ny
	 */
	public void setXY(double nx, double ny) {
		x = nx;
		y = ny;
	}
	
	public int getID() {return ItemID; }
	/**
	 * draw a circle into the interface bi
	 * @param bi
	 */
	public void drawItem(MyCanvas mc) { // calls show cirlce functionn from myCanvas
		mc.showCircle(x, y, rad, col);
	}
	protected String getStrType() { 
		return "Item";
	}
	/** 
	 * return string describing ball
	 */
	public String toString() {
		return getStrType()+ ItemID + " at "+Math.round(x)+", "+Math.round(y); // prints the x+y onn the side of the canvas
	}
	/**
	 * abstract method for checking a item in arena r
	 * @param R
	 */

	
	
	
	
	
	protected abstract void checkItem(RobotArena R); // abstract method for adjusting a item (?moving it)
	
	protected abstract void adjustItem();
	/**
	 * is item at ox,oy size or hitting this ball
	 * @param ox
	 * @param oy
	 * @param or
	 * @return true if hitting
	 */
	public boolean hitting(double ox, double oy, double or) {
		return (ox-x)*(ox-x) + (oy-y)*(oy-y) < (or+rad)*(or+rad);
	}		// hitting if dist between item and ox,oy < ist rad + or
	
	/** is item hitting the other items
	 * 
	 * @param item - the other item
	 * @return true if hitting
	 */
	public boolean hitting (ArenaItem oItem) {
		return hitting(oItem.getX(), oItem.getY(), oItem.getRad());
	}
	
	
	
	public boolean contains(double mouseX, double mouseY) {
	    // Assuming x, y, and radius are instance variables of your ArenaItem
	    double distance = Math.sqrt(Math.pow(mouseX - x, 2) + Math.pow(mouseY - y, 2));
	    return distance <= rad;
	}

	



//	protected abstract void wheels(MyCanvas mc);}

}
